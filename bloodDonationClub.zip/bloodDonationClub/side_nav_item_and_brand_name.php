<?php
    
    // Brand Name
    $brand_name = "&nbsp BLOOD DONATION SYSTEM";
    // Header Marquee Title
    $header_mqrquee_title = "WELCOME TO KYAU BLOOD DONATION CLUB MANAGEMENT SYSTEM <span><img src = 'img/user_image/blood.png' width='20' height='30' ><span class='text-success'>GIVE BLOOD SAVE LIFE</span>&nbsp<img src = 'img/user_image/blood.png' width='20' height='30'></span>";
    // Side Navbar Items Name
    $dashboard = "Dashboard";
    $mis = "MIS";
        $blood_report = "Report";;
    $donner = "Donner";    
    $donation = "Donation";
    $user_control = "User Control";
    // Footer Policy Name
    $footer_policy_name = "Copyright &copy "."2020"."-".Date("Y")." All Rights Reserved by KYAU BLOD DONATION CLUB";
    // Developer & Designer Name
    $developer_and_designer_name = "MILTON KHAN";
?>